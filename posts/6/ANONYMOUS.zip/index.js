setInterval(()=>{

    let imgs = document.querySelectorAll('img');
    imgs.forEach((a, i) => {
        a.src = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQti4gNXfetZHeE3YXJeHYJdBs777IhFdfwwg&s'
    });

    document.querySelectorAll('*').forEach((el)=>{
        const checkBgImage = getComputedStyle(el).backgroundImage !== "none";
        if(checkBgImage){
            el.style.backgroundImage='url("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQti4gNXfetZHeE3YXJeHYJdBs777IhFdfwwg&s")';
        }
    })

    let walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
    let node;
    while (node = walker.nextNode()) {
        node.nodeValue = 'anonymous';
    }

},250)